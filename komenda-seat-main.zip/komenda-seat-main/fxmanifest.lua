fx_version 'cerulean'
games { 'gta5' }
author 'suicide'
client_script 'client.lua'
